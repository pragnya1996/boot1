package userlogin1;

import java.io.IOException;

import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String s=request.getParameter("username");
		String m=request.getParameter("password");
		String n=request.getParameter("u_type");
		int flag=0;
		/*if(s.equals("pragnya") && m.equals("prabhu") ){
			response.sendRedirect("success.html");
return;
		}
		else
		{
			response.sendRedirect("error.html");
			return;
		}*/
		ArrayList<pojo1> a=new ArrayList<pojo1>();
		pojo1[] p=new pojo1[10];
		p[0]=new pojo1("prag","prag","admin");
		p[1]=new pojo1("prab","admin","new user");
		p[2]=new pojo1("pragprab","pragnya","admin");
		p[3]=new pojo1("prag","prabhu","new user");
		for(int i=0;i<4;i++){
			System.out.println("inside loop");
			if(p[i].getUsername().equals(s) && p[i].getPassword().equals(m)){
				flag++;
				
			
			if(p[i].getUsertype().equals(n)){
				response.sendRedirect("admin.html");
				
			}
			else if(p[i].getUsertype().equals(n)){
				response.sendRedirect("newuser.html");
				
			}
		}
		
		
		
		
	}
		System.out.println("outside loop");
		if(flag==0){
			response.sendRedirect("error.html");
			
		}

		
}
}
